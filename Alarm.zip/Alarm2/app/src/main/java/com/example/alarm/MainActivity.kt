package com.example.alarm



import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var btnSetAlarm: Button
    private lateinit var btnSelectSound: Button
    private lateinit var tvSelectedTime: TextView
    private lateinit var tvSelectedSound: TextView
    private lateinit var switch840: Switch
    private lateinit var switch855: Switch
    private lateinit var switch905: Switch

    private var selectedHour = 9
    private var selectedMinute = 10
    private var selectedSoundUri: Uri? = null
    private var selectedSoundName: String = "Стандартный звук"

    private var alarmManager: AlarmManager? = null
    private var pendingIntent: PendingIntent? = null

    companion object {
        const val REQUEST_CODE_PERMISSION = 100
        const val EXTRA_ALARM_TIME = "alarm_time"
        const val EXTRA_ALARM_SOUND = "alarm_sound"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupListeners()
        checkPermissions()
    }

    private fun initViews() {
        btnSetAlarm = findViewById(R.id.btnSetAlarm)
        btnSelectSound = findViewById(R.id.btnSelectSound)
        tvSelectedTime = findViewById(R.id.tvSelectedTime)
        tvSelectedSound = findViewById(R.id.tvSelectedSound)
        switch840 = findViewById(R.id.switch840)
        switch855 = findViewById(R.id.switch855)
        switch905 = findViewById(R.id.switch905)

        alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        tvSelectedTime.text = "Выбрано время: 09:10"
        tvSelectedSound.text = "Звук: $selectedSoundName"
    }

    private fun setupListeners() {
        btnSetAlarm.setOnClickListener {
            showTimePicker()
        }

        btnSelectSound.setOnClickListener {
            selectAlarmSound()
        }

        switch840.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) setQuickAlarm(8, 40)
        }

        switch855.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) setQuickAlarm(8, 55)
        }

        switch905.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) setQuickAlarm(9, 5)
        }
    }

    private fun showTimePicker() {
        val timePickerDialog = TimePickerDialog(
            this,
            { _, hour, minute ->
                selectedHour = hour
                selectedMinute = minute
                tvSelectedTime.text = String.format("Выбрано время: %02d:%02d", hour, minute)
                setAlarm(hour, minute)
            },
            selectedHour,
            selectedMinute,
            true
        )
        timePickerDialog.show()
    }

    private fun selectAlarmSound() {
        val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Выберите звук будильника")
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, selectedSoundUri)
        startActivityForResult(intent, 101)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK) {
            selectedSoundUri = data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            if (selectedSoundUri != null) {
                val ringtone = RingtoneManager.getRingtone(this, selectedSoundUri)
                selectedSoundName = ringtone.getTitle(this) ?: "Выбранный звук"
                tvSelectedSound.text = "Звук: $selectedSoundName"
            }
        }
    }

    private fun setAlarm(hour: Int, minute: Int) {
        val calendar = Calendar.getInstance().apply {
            timeInMillis = System.currentTimeMillis()
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)

            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_MONTH, 1)
            }
        }

        setAlarmManager(calendar.timeInMillis)
        Toast.makeText(this, "Будильник установлен на ${String.format("%02d:%02d", hour, minute)}", Toast.LENGTH_SHORT).show()
    }

    private fun setQuickAlarm(hour: Int, minute: Int) {
        selectedHour = hour
        selectedMinute = minute
        tvSelectedTime.text = String.format("Выбрано время: %02d:%02d", hour, minute)
        setAlarm(hour, minute)
    }

    private fun setAlarmManager(timeInMillis: Long) {
        val intent = Intent(this, AlarmReceiver::class.java).apply {
            putExtra(EXTRA_ALARM_SOUND, selectedSoundUri.toString())
        }

        pendingIntent = PendingIntent.getBroadcast(
            this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // ИСПРАВЛЕНИЕ: используем безопасный вызов с let
        pendingIntent?.let { pi ->
            alarmManager?.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                timeInMillis,
                pi
            )
        }
    }

    private fun checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SCHEDULE_EXACT_ALARM)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.SCHEDULE_EXACT_ALARM),
                    REQUEST_CODE_PERMISSION
                )
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    REQUEST_CODE_PERMISSION
                )
            }
        }
    }

    fun cancelAlarm() {
        // ИСПРАВЛЕНИЕ: используем безопасный вызов с let
        pendingIntent?.let { pi ->
            alarmManager?.cancel(pi)
        }
    }
}
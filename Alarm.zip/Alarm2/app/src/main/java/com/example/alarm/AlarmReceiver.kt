package com.example.alarm


import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings

class AlarmReceiver : BroadcastReceiver() {

    companion object {
        var mediaPlayer: MediaPlayer? = null
        var vibrator: Vibrator? = null
        const val EXTRA_SOUND_URI = "alarm_sound"

        // Паттерн вибрации: [ожидание, вибрация, ожидание, вибрация, ...]
        private val vibrationPattern = longArrayOf(0, 500, 200, 500, 200, 500)

        fun stopAlarm() {
            // Останавливаем звук
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.stop()
                }
                it.release()
                mediaPlayer = null
            }

            // Останавливаем вибрацию
            vibrator?.let {
                it.cancel()
                vibrator = null
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        val soundUriString = intent.getStringExtra(EXTRA_SOUND_URI)

        // Запускаем звук будильника
        playAlarmSound(context, soundUriString)

        // Запускаем вибрацию
        startVibration(context)

        // Запускаем активность с загадкой
        val riddleIntent = Intent(context, RiddleActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(RiddleActivity.EXTRA_SOUND_URI, soundUriString)
        }
        context.startActivity(riddleIntent)
    }

    private fun playAlarmSound(context: Context, soundUriString: String?) {
        try {
            mediaPlayer = MediaPlayer().apply {
                val uri = if (soundUriString != null) {
                    Uri.parse(soundUriString)
                } else {
                    Settings.System.DEFAULT_ALARM_ALERT_URI
                }

                setDataSource(context, uri)
                isLooping = true
                prepare()
                start()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun startVibration(context: Context) {
        try {
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                // Android 12+
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vibratorManager.defaultVibrator
            } else {
                // Старые версии Android
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }

            vibrator?.let { vib ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    // Android 8.0+
                    vib.vibrate(VibrationEffect.createWaveform(vibrationPattern, 0))
                } else {
                    // Старые версии
                    @Suppress("DEPRECATION")
                    vib.vibrate(vibrationPattern, 0)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
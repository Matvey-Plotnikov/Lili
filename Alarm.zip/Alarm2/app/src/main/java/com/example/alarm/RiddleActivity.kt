package com.example.alarm

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton

class RiddleActivity : AppCompatActivity() {

    private lateinit var tvRiddleTitle: TextView
    private lateinit var tvRiddleText: TextView
    private lateinit var etAnswer: EditText
    private lateinit var btnCheck: AppCompatButton
    private lateinit var btnHint: AppCompatButton

    private val correctAnswer = "будильник"
    private var attemptCount = 0

    private val hints = listOf(
        "Это устройство помогает проснуться утром",
        "Оно звонит в установленное время",
        "Без него можно проспать на работу"
    )

    companion object {
        const val EXTRA_SOUND_URI = "alarm_sound"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_riddle)

        initViews()
        setupListeners()

        // Показываем первую загадку
        showRiddle()
    }

    private fun initViews() {
        tvRiddleTitle = findViewById(R.id.tvRiddleTitle)
        tvRiddleText = findViewById(R.id.tvRiddleText)
        etAnswer = findViewById(R.id.etAnswer)
        btnCheck = findViewById(R.id.btnCheck)
        btnHint = findViewById(R.id.btnHint)
    }

    private fun setupListeners() {
        btnCheck.setOnClickListener {
            checkAnswer()
        }

        btnHint.setOnClickListener {
            showHint()
        }
    }

    private fun showRiddle() {
        tvRiddleTitle.text = "ЗАГАДКА"
        tvRiddleText.text = """
            Я утром каждого бужу,
            Хотя сам с места не хожу.
            Со мной не проспишь ты в кровать,
            Скажи, кто я? Нужно отгадать!
        """.trimIndent()
    }

    private fun checkAnswer() {
        val userAnswer = etAnswer.text.toString().trim().lowercase()

        if (userAnswer.isEmpty()) {
            Toast.makeText(this, "Введите ответ!", Toast.LENGTH_SHORT).show()
            return
        }

        attemptCount++

        if (userAnswer == correctAnswer) {
            // Правильный ответ - останавливаем будильник и вибрацию
            AlarmReceiver.stopAlarm()

            Toast.makeText(
                this,
                "Правильно! Будильник выключен.\nПопыток: $attemptCount",
                Toast.LENGTH_LONG
            ).show()

            // Задерживаем закрытие на 2 секунды
            Handler(Looper.getMainLooper()).postDelayed({
                finish()
            }, 2000)

        } else {
            // Неправильный ответ - будильник продолжает звонить
            val message = when {
                attemptCount < 3 -> "Неправильно! Попробуйте еще раз. Попытка $attemptCount"
                attemptCount < 5 -> "Подумайте лучше! Будильник продолжает звонить..."
                else -> "Упорный вы! Но будильник не сдаётся!"
            }

            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
            etAnswer.text.clear()

            // Усиливаем вибрацию при неправильном ответе
            vibratePhone()
        }
    }

    private fun showHint() {
        val hintIndex = minOf(attemptCount / 2, hints.size - 1)
        Toast.makeText(this, "Подсказка: ${hints[hintIndex]}", Toast.LENGTH_LONG).show()
    }

    private fun vibratePhone() {
        try {
            val vibrator = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(android.content.Context.VIBRATOR_MANAGER_SERVICE) as android.os.VibratorManager
                vibratorManager.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(android.content.Context.VIBRATOR_SERVICE) as android.os.Vibrator
            }

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                vibrator.vibrate(android.os.VibrationEffect.createOneShot(500, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(500)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onBackPressed() {
        // Запрещаем выход назад без отгадывания загадки
        Toast.makeText(this, "Отгадайте загадку, чтобы выключить будильник!", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Убеждаемся, что будильник и вибрация остановлены
        AlarmReceiver.stopAlarm()
    }
}